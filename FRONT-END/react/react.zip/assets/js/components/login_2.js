 // Lógica del componente
    class LoginForm extends React.Component {
      constructor(props) {
        super(props);
        this.state = {
          email: '',
          password: '',
          error: ''
        };
      }

      handleChange = (e) => {
        this.setState({
          [e.target.name]: e.target.value,
          error: ''
        });
      }

      handleSubmit = (e) => {
        e.preventDefault();
        
        // Validación simple
        if (!this.state.email || !this.state.password) {
          this.setState({ error: 'Todos los campos son requeridos' });
          return;
        }

        // Simular envío de datos
        console.log('Datos enviados:', {
          email: this.state.email,
          password: this.state.password
        });

        // Aquí normalmente harías una petición HTTP
        alert(`Bienvenido, ${this.state.email}`);
      }

      render() {
        return (
          <div className="login-container">
            <h2>Iniciar Sesión</h2>
            {this.state.error && <div className="error">{this.state.error}</div>}
            
            <form onSubmit={this.handleSubmit}>
              <div className="form-group">
                <label>Correo electrónico:</label>
                <input
                  type="email"
                  name="email"
                  value={this.state.email}
                  onChange={this.handleChange}
                  placeholder="tu@email.com"
                />
              </div>

              <div className="form-group">
                <label>Contraseña:</label>
                <input
                  type="password"
                  name="password"
                  value={this.state.password}
                  onChange={this.handleChange}
                  placeholder="••••••••"
                />
              </div>

              <button type="submit">Ingresar</button>
            </form>
            
          </div>
        );
      }
    }

    // Renderizar la aplicación
    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(<LoginForm />);